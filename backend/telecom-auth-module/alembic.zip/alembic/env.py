"""Alembic migration environment (async-aware).

Integrates with the existing project:
- Database URL comes from app.core.config.settings (no creds in alembic.ini).
- target_metadata is Base.metadata from app/db/base.py.
- Importing app.models registers every table on that metadata so autogenerate
  sees the full schema. Models are NOT modified.

The project engine uses asyncpg, so migrations run through an async engine.
"""
import asyncio
import os
import sys
from logging.config import fileConfig

from sqlalchemy import pool, text
from sqlalchemy.engine import Connection
from sqlalchemy.ext.asyncio import async_engine_from_config

from alembic import context

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
# --- Project wiring --------------------------------------------------------
from app.core.config import settings
from app.db.base import Base

# Side-effect import: registers all models on Base.metadata. Required for
# autogenerate to detect every table. Do not remove.
import app.models  # noqa: F401

# Alembic Config object (values from alembic.ini).
config = context.config

# Inject the URL from app settings so there's a single source of truth.
config.set_main_option("sqlalchemy.url", settings.DATABASE_URL)

# Configure logging from alembic.ini if present.
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# The metadata autogenerate compares against.
target_metadata = Base.metadata


def _configure(connection: Connection) -> None:
    """Shared context configuration for online runs."""
    context.configure(
        connection=connection,
        target_metadata=target_metadata,
        # Detect column type changes during autogenerate.
        compare_type=True,
        # Detect server-default changes (we use server_default in models).
        compare_server_default=True,
        # Render native enum/array etc. on the postgresql dialect cleanly.
        render_as_batch=False,
    )


def run_migrations_offline() -> None:
    """Run migrations without a DBAPI connection (emits SQL to stdout)."""
    context.configure(
        url=settings.DATABASE_URL,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        compare_type=True,
        compare_server_default=True,
    )
    with context.begin_transaction():
        context.run_migrations()


# PostgreSQL extensions the models depend on. The schema uses CITEXT
# (case-insensitive email) and gen_random_uuid() from pgcrypto, so these must
# exist before the baseline tables are created. Ensuring them here (rather than
# inside each migration) keeps extensions as a DB prerequisite, not schema
# content, and makes every migration run idempotently safe on a fresh database.
REQUIRED_EXTENSIONS = ("pgcrypto", "citext")


def _ensure_extensions(connection: Connection) -> None:
    for ext in REQUIRED_EXTENSIONS:
        connection.execute(text(f'CREATE EXTENSION IF NOT EXISTS "{ext}"'))


def do_run_migrations(connection: Connection) -> None:
    _ensure_extensions(connection)
    _configure(connection)
    with context.begin_transaction():
        context.run_migrations()


async def run_async_migrations() -> None:
    """Create an async engine and run migrations within its connection."""
    connectable = async_engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    async with connectable.connect() as connection:
        await connection.run_sync(do_run_migrations)
        await connection.commit()
    await connectable.dispose()


def run_migrations_online() -> None:
    asyncio.run(run_async_migrations())


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
